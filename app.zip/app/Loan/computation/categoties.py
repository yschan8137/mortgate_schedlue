amortization = dict(
    EQUAL_TOTAL= "本息攤還法", 
    EQUAL_PRINCIPAL= "本金攤還法" 
    )