from app.Loan.computation.categoties import amortization as amortization_types  # type: ignore

# amortization_types = [*amortization]
