from dash import html, register_page  #, callback # If you need callbacks, import it here.
import dash_bootstrap_components as dbc
from app.Dashboard.components.Controls.main import panel

register_page(
    __name__,
    name='Home',
    top_nav=True,
    path='/'
)


def layout():
    layout = html.Div(
        [
            panel.front()
        ]
    )
    return layout