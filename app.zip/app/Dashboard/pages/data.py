from dash import html, register_page, callback
from app.Dashboard.components.DataTable.app import deployment
import dash_bootstrap_components as dbc

register_page(
    __name__,
    name='data',
    top_nav=True,
    path='/data',
    suppress_callback_exceptions=True,
)

def layout():
    layout = dbc.Container(
        [
            deployment(),
        ]
    )
    return layout