from dash import Dash, html, dcc, Input, Output, State, page_container
import dash_bootstrap_components as dbc
from app.Dashboard.components.Controls.main import panel
from app.Dashboard.components.Controls.options import AdvancedOptions
from app.Dashboard.components.ids import APP
from app.Dashboard.navbar import create_navbar

# https://dash.plotly.com/urls
# Template reference from: https://medium.com/@mcmanus_data_works/how-to-create-a-multipage-dash-app-261a8699ac3f


NAVBAR = create_navbar()
# To use Font Awesome Icons
FA621 = "https://use.fontawesome.com/releases/v6.2.1/css/all.css"
APP_TITLE = "Amort"

app = Dash(
    __name__,
    suppress_callback_exceptions=True,
    external_stylesheets=[
        dbc.themes.LUMEN,  # Dash Themes CSS
        dbc.icons.BOOTSTRAP,
        FA621,  # Font Awesome Icons CSS
    ],
    title=APP_TITLE,
    use_pages=True, 
)

# To use if you're planning on using Google Analytics
app.index_string = f'''
    <!DOCTYPE html>
    <html>
        <head>
            {{%metas%}}
            <title>{APP_TITLE}</title>
            {{%favicon%}}
            {{%css%}}
        </head>
        <body>
            {{%app_entry%}}
            <footer>
                {{%config%}}
                {{%scripts%}}
                {{%renderer%}}
            </footer>
        </body>
    </html>
    '''

app.layout = dcc.Loading(  # <- Wrap App with Loading Component
    id= APP.LOADING,
    children=[
        html.Div(
            [
                NAVBAR,
                page_container
            ]
        )
    ],
    color='primary',  # <- Color of the loading spinner
    fullscreen=True  # <- Loading Spinner should take up full screen
)

server = app.server

# py -m app.Dashboard.app
if __name__ == '__main__':
    app.run_server(debug=True, threaded=True)